/**
 * PodcastController
 *
 * @description :: Server-side logic for managing Podcasts
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {

	// podcast: function (req, res) {
	//     var pTitle = req.param("pTitle");
	//     var URL = req.param("URL");

	// 	var post  = {podcastId: 10, pTitle: 'Hello'};
	// 	var query = connection.query('INSERT INTO ecabinetDatabase.Podcasts', post, function (error, results, fields) {
	// 	  if (error) throw error;
	// 	  // Neat!
	// 	});
	// 	console.log(query.sql); // INSERT INTO posts SET `id` = 1, `title` = 'Hello MySQL'


	 //    connections.query('INSERT INTO ecabinetDatabase.podcast 2, James1, NULL, NULL, NULL, 1, NULL,NULL', function (error, results, fields) {
		//   if (error) throw error;
		//   console.log('The solution is: ', results[0].solution);
		// });
	    
	    // Podcasts.create({pTitle: pTitle, URL: URL}).done(function(error, user) {
	    //         if (error) {
	    //             res.send(500, {error: "DB Error"});
	    //         } else {
	    //             req.session.user = user;
	    //             res.send(user);
	    //         	}
     //    	});

	    
	 //    Podcast.findBypTitle(pTitle).done(function(err, usr){
	 //        if (err) {
	 //            res.send(500, { error: "DB Error" });
	 //        } else if (usr) {
	 //            res.send(400, {error: "pTitle already Taken"});
	 //        } else {        
	 //            Podcast.create({pTitle: pTitle, URL: URL}).done(function(error, user) {
	 //            if (error) {
	 //                res.send(500, {error: "DB Error"});
	 //            } else {
	 //                req.session.user = user;
	 //                res.send(user);
	 //            	}
	 //        	});
	 //    	}
		// });
	
	count: function(req, res) {
		return Podcast.count().exec(function countCB(error, found) {
			res.send(200, found);
		});
	}
};

