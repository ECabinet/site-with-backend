/**
 * ViewedPodcastController
 *
 * @description :: Server-side logic for managing viewedpodcasts
 * @help        :: See http://sailsjs.org/#!/documentation/concepts/Controllers
 */

module.exports = {
	
};

